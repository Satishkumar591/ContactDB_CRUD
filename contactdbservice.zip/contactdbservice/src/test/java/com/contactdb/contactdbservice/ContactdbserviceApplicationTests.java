package com.contactdb.contactdbservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactdbserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
